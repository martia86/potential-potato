awesomeFile.exe - BotNet
Size: 126kb

When awesomeFile.exe is executed it shows a notepad file that is stored in My Documents and deleted after the text file is closed.
When the text file is closed, it quickly copies everything to startup and other available drives than C drive and quits the program.
This way, the user will not get suspicious by the worm, and when trying to delete, it would not show the user "The program is in use" error, and it is only detected by 3 anti-viruses.

This worm went undetected from very good anti-viruses such as "Kaspersky" and "McAfee", so it should be good to go.
Made by: why do you wanna know? to put me in jail?


WARNING: This is made just for fun, do not abuse.
Note: The hidden string "Idiots are useless, this makes a use of them." exists in the Program.cs file.


Here is the summary of its scan from virustotal.com:
https://www.virustotal.com/gui/file/bd708249db4e37e668aea0dfff71858c6cc8e5211a9c1e3ffc8a387c4d803215/detection